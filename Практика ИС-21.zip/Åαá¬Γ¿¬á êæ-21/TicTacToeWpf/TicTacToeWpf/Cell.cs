﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace TicTacToeWpf
{
    public class Cell
    {
        public int id { get; set; }
        public Button cell{ get; set; }
    }
}
